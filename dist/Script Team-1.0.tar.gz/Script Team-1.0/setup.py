from distutils.core import setup

setup(name='Script Team',
    version='1.0',
    py_modules=['Script Team'],
   )
